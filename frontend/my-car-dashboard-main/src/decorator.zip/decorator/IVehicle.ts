export interface IVehicle {
  getDescription(): string;
  getPrice(): number;
}
